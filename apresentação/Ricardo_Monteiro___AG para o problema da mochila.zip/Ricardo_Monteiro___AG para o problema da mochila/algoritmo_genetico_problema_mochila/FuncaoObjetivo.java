package algoritmo_genetico_problema_mochila; 

public class FuncaoObjetivo {
	
	private double CAPACIDADE_MOCHILA;
	
	private double[] pesos;
	private double[] beneficios;

	public FuncaoObjetivo(double[] pesos, double[] beneficios, double CAPACIDADE_MOCHILA) {
		this.CAPACIDADE_MOCHILA = CAPACIDADE_MOCHILA;
		this.pesos = pesos;
		this.beneficios = beneficios;
	}

	public double calcula(Individuo individuo) {
		double peso = 0.0;
		double beneficio = 0.0;
		
		for(int i = 0; i < individuo.getTamanhoRepresentacao(); i++) {
			if(individuo.getGene(i) == 1) {
				beneficio += beneficios[i];	
				peso += pesos[i];
			}
		}
		
		double fitness = (peso <= CAPACIDADE_MOCHILA) ? beneficio : Double.MIN_VALUE;	
		
		individuo.setFitness(fitness);
		
		return fitness;
	}
}
