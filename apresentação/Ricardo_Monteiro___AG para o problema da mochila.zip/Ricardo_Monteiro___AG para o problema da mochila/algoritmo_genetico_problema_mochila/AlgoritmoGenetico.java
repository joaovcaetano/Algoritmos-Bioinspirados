package algoritmo_genetico_problema_mochila;

import java.util.ArrayList;
import java.util.List;

public class AlgoritmoGenetico {
	
	private final int NUMERO_GERACOES;
	private final double TAXA_MUTACAO;
	private Populacao populacao;
	private int tamanhoPopulacao;

	private List<Individuo> paisA;
	private List<Individuo> paisB;
	private Populacao novaPopulacao;
	private int tamanhoRepresentacaoIndividuo;
	private FuncaoObjetivo funcaoObjetivo;

	public AlgoritmoGenetico(Populacao populacao, FuncaoObjetivo funcaoObjetivo, int NUMERO_GERACOES, double TAXA_MUTACAO) {		
		this.populacao = populacao;
		this.funcaoObjetivo = funcaoObjetivo;
		this.NUMERO_GERACOES = NUMERO_GERACOES;
		this.TAXA_MUTACAO = TAXA_MUTACAO;		
		this.tamanhoPopulacao = populacao.getTamanhoPopulacao();
		this.tamanhoRepresentacaoIndividuo = populacao.getIndividuo(0).getTamanhoRepresentacao();
		this.paisA = new ArrayList<>();
		this.paisB = new ArrayList<>();		
		this.novaPopulacao = new Populacao();
	}
	
	public double executa() {
		double melhorResultado = 0.0;
		
		avaliarPopulacao(populacao);
		
		if(melhorResultado < populacao.getResultadoMelhorIndividuo()) {
			melhorResultado = populacao.getResultadoMelhorIndividuo();
		}
		
		for(int i = 1; i < NUMERO_GERACOES + 1; i++) {		
			//selecaoTorneio();
			selecaoRoleta();
			crossOverOnePoint();
			mutacao();
			avaliarPopulacao(novaPopulacao);
			
			if(melhorResultado < novaPopulacao.getResultadoMelhorIndividuo()) {
				melhorResultado = novaPopulacao.getResultadoMelhorIndividuo();
			}
			
			populacao = novaPopulacao;
			novaPopulacao = new Populacao();			
			paisA = new ArrayList<>();
			paisB = new ArrayList<>();
		}
		
		return melhorResultado;
	}
	
	private void avaliarPopulacao(Populacao populacao) {
		populacao.avaliarPopulacao(funcaoObjetivo);
	}
	
	private void selecaoTorneio() {
		for(int i = 0; i < tamanhoPopulacao; i++) {
			int indicePaiA1 = (int) Math.floor(Math.random() * tamanhoPopulacao);
			
			int indicePaiA2;
			
			int indicePaiB1;
			
			int indicePaiB2;
			
			do {
				indicePaiA2 = (int) Math.floor(Math.random() * tamanhoPopulacao);
			} while (indicePaiA2 == indicePaiA1);
			
			do {
				indicePaiB1 = (int) Math.floor(Math.random() * tamanhoPopulacao);
			} while (indicePaiB1 == indicePaiA1 || indicePaiB1 == indicePaiA2);
			
			do {
				indicePaiB2 = (int) Math.floor(Math.random() * tamanhoPopulacao);
			} while (indicePaiB2 == indicePaiA1 || indicePaiB2 == indicePaiA2 || indicePaiB2 == indicePaiB1);
						
			Individuo paiA1 = populacao.getIndividuo(indicePaiA1);
			Individuo paiA2 = populacao.getIndividuo(indicePaiA2);
			Individuo paiB1 = populacao.getIndividuo(indicePaiB1);
			Individuo paiB2 = populacao.getIndividuo(indicePaiB2);
			
			if(paiA1.getFitness() < paiA2.getFitness()) {
				paisA.add(paiA1);
			} else {
				paisA.add(paiA2);
			}
			
			if(paiB1.getFitness() < paiB2.getFitness()) {
				paisB.add(paiB1);
			} else {
				paisB.add(paiB2);
			}
		}
	}
	
	private void selecaoRoleta() {
		double roleta = 0.0;
		double[] probabilidadeIndividuos = new double[tamanhoPopulacao];
		for(int i = 0; i < tamanhoPopulacao; i++) {
			Individuo individuo = populacao.getIndividuo(i);
			probabilidadeIndividuos[i] = individuo.getFitness();
			roleta += individuo.getFitness();
		}
		
		
		for(int i = 0; i < tamanhoPopulacao; i++) {
			probabilidadeIndividuos[i] = (probabilidadeIndividuos[i] * 100) / roleta;
		}
		
		
		for(int k = 0; k < tamanhoPopulacao; k++) {	
			double random = Math.random() * 100.0;
			double soma = 0.0;
			for(int i = 0; i < tamanhoPopulacao; i++) {
				soma += probabilidadeIndividuos[i];
				if(soma < random) {
					continue;
				} else {
					paisA.add(populacao.getIndividuo(i));
				}
			}
			
			random = Math.random() * 100;
			soma = 0.0;
			for(int i = 0; i < tamanhoPopulacao; i++) {
				soma += probabilidadeIndividuos[i];
				if(soma < random) {
					continue;
				} else {
					paisB.add(populacao.getIndividuo(i));
				}
			}
		}		
	}
	
	private void crossOverOnePoint() {
		for(int i = 0; i < tamanhoPopulacao; i++) {
			Individuo paiA = paisA.get(i);
			Individuo paiB = paisB.get(i);
			int[] representacaoFilho = new int[tamanhoRepresentacaoIndividuo];
			
			int j;
			
			for(j = 0; j < tamanhoRepresentacaoIndividuo / 2; j++) {				
				representacaoFilho[j] = paiA.getGene(j);
			}
			
			for(; j < tamanhoRepresentacaoIndividuo; j++) {				
				representacaoFilho[j] = paiB.getGene(j);
			}
			
			Individuo filho = new Individuo(representacaoFilho);
			novaPopulacao.addIndividuo(filho);
		}
	}
	
	private void mutacao() {
		for(Individuo filho : novaPopulacao.getPopulacao()) {	
			for(int i = 0; i < filho.getTamanhoRepresentacao(); i++) {
				double rand = Math.random();
				if(rand < TAXA_MUTACAO ) {
					int geneMutado = Math.abs(filho.getGene(i) - 1);
					filho.setGene(i, geneMutado);
				} 
			}
		}
	}

}
