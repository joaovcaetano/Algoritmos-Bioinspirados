package algoritmo_genetico_problema_mochila;

import java.util.ArrayList;
import java.util.List;

public class Populacao {
	
	private List<Individuo> populacao;
	private Individuo melhorIndividuo;
	
	
	public Populacao() {
		this.populacao = new ArrayList<>();
	}
	
	public List<Individuo> getPopulacao() {
		return populacao;
	}
	
	public Individuo getMelhorIndividuo() {
		return melhorIndividuo;
	}
	
	public double getResultadoMelhorIndividuo() {
		return melhorIndividuo.getFitness();
	}
	
	public int getTamanhoPopulacao() {
		return populacao.size();
	}
	
	public Individuo getIndividuo(int indice) {
		return populacao.get(indice);
	}
	
	public void addIndividuo(Individuo individuo) {
		populacao.add(individuo);
	}
	
	public void avaliarPopulacao(FuncaoObjetivo fucaoObjetivo) {		
		for(Individuo individuo : populacao) {
			fucaoObjetivo.calcula(individuo);
			if(melhorIndividuo == null || melhorIndividuo.getFitness() < individuo.getFitness()) {
				melhorIndividuo = individuo;
			}
		}
	}
}
