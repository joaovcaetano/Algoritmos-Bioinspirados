package algoritmo_genetico_problema_mochila;

public class Individuo {
	
	private int[] representacao;
	private double fitness;

	public Individuo(int[] representacao) {
		this.representacao = representacao;
	}
	
	public void setFitness(double fitness) {
		this.fitness = fitness;
	}
	
	public double getFitness() {
		return fitness;
	}
	
	public int[] getRepresentacao() {
		return representacao;
	}
	
	public int getTamanhoRepresentacao() {
		return representacao.length;
	}
	
	public int getGene(int indice) {
		return representacao[indice];
	}
	
	public void setGene(int indice, int valorGene) {
		representacao[indice] = valorGene;
	}
}

