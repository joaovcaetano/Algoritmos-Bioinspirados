package algoritmo_genetico_problema_mochila;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
	
	private static int NUMERO_DE_EXECUCOES_DO_AG = 100;
	private static int NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG;
	private static double TAXA_MUTACAO = 0.15;
	private static int TAMANHO_POPULACAO;
	private static int QUANTIDADE_GENES_INDIVIDUO;
	
	public static void main(String [] args) { 
		double[] melhoresResultados = new double[NUMERO_DE_EXECUCOES_DO_AG];
		FuncaoObjetivo funcaoObjetivo = exibeInterfaceUsuario();
		
		if(funcaoObjetivo != null) {
			Populacao populacao = new Populacao();
			int[] representacaoIndividuo = new int[QUANTIDADE_GENES_INDIVIDUO];
			
			for(int z = 0; z < TAMANHO_POPULACAO; z++) {
				for(int i = 0; i < QUANTIDADE_GENES_INDIVIDUO; i++) {
					int rand = (int) Math.floor(Math.random() * 2);
					representacaoIndividuo[i] = rand;
				}
				populacao.addIndividuo(new Individuo(representacaoIndividuo));
				representacaoIndividuo = new int[QUANTIDADE_GENES_INDIVIDUO];
			}
			
			for(int i = 0; i < NUMERO_DE_EXECUCOES_DO_AG; i++) {
				melhoresResultados[i] = new AlgoritmoGenetico(populacao, funcaoObjetivo, NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG, TAXA_MUTACAO).executa();
			}
			
			imprimeResultados(melhoresResultados);	
		} else {
			System.out.println("PROGRAMA ENCERRADO!");
			System.exit(0);
		}
	}
	
	private static FuncaoObjetivo exibeInterfaceUsuario() {
		double CAPACIDADE_MOCHILA;
		double[] pesos;
		double[] beneficios;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Escolha a instancia para execucao:");
		System.out.println("1 - instancia P01 (Ate 10 objetos e 165 de capacidade)");
		System.out.println("2 - instancia P02 (Ate 5 objetos e 26 de capacidade)");
		System.out.println("3 - instancia P03 (Ate 6 objetos e 190 de capacidade)");
		System.out.println("4 - instancia P04 (Ate 7 objetos e 50 de capacidade)");
		System.out.println("5 - instancia P05 (Ate 8 objetos e 104 de capacidade)");
		System.out.println("6 - instancia P06 (Ate 7 objetos e 170 de capacidade)");
		System.out.println("7 - instancia P07 (Ate 15 objetos e 750 de capacidade)");
		System.out.println("8 - instancia P08 (Ate 24 objetos e 6404180 de capacidade)");
		System.out.println("9 - instancia fornecida em aula (Ate 8 objetos e 100 de capacidade)");
		System.out.println("0 - Encerrar o programa.");
		System.out.println("Informe a opcao:");
		
		int option = sc.nextInt();
		sc.close();
		
		switch(option) {
		case 1:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 100;
			TAMANHO_POPULACAO = 100;
			QUANTIDADE_GENES_INDIVIDUO = 10;
			CAPACIDADE_MOCHILA = 165.0;		
			pesos = new double[]{23, 31, 29, 44, 53, 38, 63, 85, 89, 82};
			beneficios = new double[]{92, 57, 49, 68, 60, 43, 67, 84, 87, 72};
			
			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		case 2:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 100;
			TAMANHO_POPULACAO = 100;
			QUANTIDADE_GENES_INDIVIDUO = 5;
			CAPACIDADE_MOCHILA = 26.0;		
			pesos = new double[]{12, 7, 11, 8, 9};
			beneficios = new double[]{24, 13, 23, 15, 16};

			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		case 3:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 100;
			TAMANHO_POPULACAO = 100;
			QUANTIDADE_GENES_INDIVIDUO = 6;
			CAPACIDADE_MOCHILA = 190.0;		
			pesos = new double[]{56, 59, 80, 64, 75, 17};
			beneficios = new double[]{50, 50, 64, 46, 50, 5};

			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		case 4:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 100;
			TAMANHO_POPULACAO = 100;
			QUANTIDADE_GENES_INDIVIDUO = 7;
			CAPACIDADE_MOCHILA = 50.0;		
			pesos = new double[]{31, 10, 20, 19, 4, 3, 6};
			beneficios = new double[]{70, 20, 39, 37, 7, 5, 10};

			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		case 5:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 100;
			TAMANHO_POPULACAO = 100;
			QUANTIDADE_GENES_INDIVIDUO = 8;
			CAPACIDADE_MOCHILA = 104.0;		
			pesos = new double[]{25, 35, 45, 5, 25, 3, 2, 2};
			beneficios = new double[]{350, 400, 450, 20, 70, 8, 5, 5};

			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		case 6:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 100;
			TAMANHO_POPULACAO = 100;
			QUANTIDADE_GENES_INDIVIDUO = 7;
			CAPACIDADE_MOCHILA = 170.0;		
			pesos = new double[]{41, 50, 49, 59, 55, 57, 60};
			beneficios = new double[]{442, 525, 511, 593, 546, 564, 617};

			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		case 7:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 1000;
			TAMANHO_POPULACAO = 350;
			QUANTIDADE_GENES_INDIVIDUO = 15;
			CAPACIDADE_MOCHILA = 750.0;		
			pesos = new double[]{70, 73, 77, 80, 82, 87, 90, 94, 98, 106, 110, 113, 115, 118, 120};
			beneficios = new double[]{135, 139, 149, 150, 156, 163, 173, 184, 192, 201, 210, 214, 221, 229, 240};

			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		case 8:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 1000;
			TAMANHO_POPULACAO = 1000;
			QUANTIDADE_GENES_INDIVIDUO = 24;
			CAPACIDADE_MOCHILA = 6404180;
			pesos = new double[]{382745, 799601, 909247, 729069, 467902, 44328, 34610, 698150, 823460, 903959, 853665, 551830, 610856, 670702, 488960, 951111, 323046, 446298, 931161, 31385, 496951, 264724, 224916, 169684};
			beneficios = new double[]{825594, 1677009, 1676628, 1523970, 943972, 97426, 69666, 1296457, 1679693, 1902996, 1844992, 1049289, 1252836, 1319836, 953277, 2067538, 675367, 853655, 1826027, 65731, 901489, 577243, 466257, 369261};	

			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		case 9:
			NUMERO_DE_GERACOES_EM_CADA_EXECUCAO_DO_AG = 100;
			TAMANHO_POPULACAO = 100;
			QUANTIDADE_GENES_INDIVIDUO = 8;
			CAPACIDADE_MOCHILA = 100;
			pesos = new double[]{1, 11, 21, 23, 33, 43, 45, 55};
			beneficios = new double[]{11, 21, 31, 33, 43, 53, 55, 65};

			return new FuncaoObjetivo(pesos, beneficios, CAPACIDADE_MOCHILA);
		default:
			return null;
		}
	}
	
	private static double calculaMediaAritmetica(double[] vetorResultadosExecucoes) {
		double media = 0.0;
		for(int i = 0; i < NUMERO_DE_EXECUCOES_DO_AG; i++) {
			media += vetorResultadosExecucoes[i];
		}
		media = media / NUMERO_DE_EXECUCOES_DO_AG;
		
		return media;
	}
	
	private static double calculaDesvioPadrao(double[] vetorResultadosExecucoes, double mediaAritmetica) {
		double variancia = 0.0;
		double somatorio = 0.0;
		double desvioPadrao = 0.0;
		
		for(int i = 0; i < NUMERO_DE_EXECUCOES_DO_AG; i++) {
			somatorio += (vetorResultadosExecucoes[i] - mediaAritmetica) * (vetorResultadosExecucoes[i] - mediaAritmetica);
		}
		
		variancia = somatorio / NUMERO_DE_EXECUCOES_DO_AG;
		
		desvioPadrao = Math.sqrt(variancia);
		
		return desvioPadrao;
	}
	
	private static double calculaMediana(double[] vetorResultadosExecucoes) {
		Arrays.sort(vetorResultadosExecucoes);
		
		if(NUMERO_DE_EXECUCOES_DO_AG % 2 == 0) {
			int indiceB = NUMERO_DE_EXECUCOES_DO_AG / 2;
			int indiceA = indiceB - 1;
			
			double valorA = vetorResultadosExecucoes[indiceA];
			double valorB = vetorResultadosExecucoes[indiceB];
			double mediana = (valorA + valorB) / 2.0;
			
			return mediana;
		} else {
			int indice = (int) Math.floor(NUMERO_DE_EXECUCOES_DO_AG / 2);
			double mediana = vetorResultadosExecucoes[indice];
			
			return mediana;
		}
	}
	
	private static double obterMelhorResultado(double[] vetorResultadosExecucoes) {
		double melhorResultado = 0.0;
		
		for(int i = 0; i < vetorResultadosExecucoes.length; i++) {
			if(melhorResultado < vetorResultadosExecucoes[i]) {
				melhorResultado = vetorResultadosExecucoes[i];
			}
		}
		
		return melhorResultado;
	}
	
	private static void imprimeResultados(double[] vetorResultadosExecucoes) {
		double melhorResultado = obterMelhorResultado(vetorResultadosExecucoes);
		double mediaAritmetica = calculaMediaAritmetica(vetorResultadosExecucoes);
		double desvioPadrao = calculaDesvioPadrao(vetorResultadosExecucoes, mediaAritmetica);
		double mediana = calculaMediana(vetorResultadosExecucoes);
		
		DecimalFormat df = new DecimalFormat("0.0");
		df.setMaximumFractionDigits(8);
		
		System.out.println("Melhor Resultado: " + df.format(melhorResultado));
		System.out.println("Media Aritmetica: " + df.format(mediaAritmetica));
		System.out.println("Desvio Padrao: " + df.format(desvioPadrao));
		System.out.println("Mediana: " + df.format(mediana));
	}
}
